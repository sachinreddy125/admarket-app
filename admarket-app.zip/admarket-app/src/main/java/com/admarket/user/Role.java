package com.admarket.user;

public enum Role { MARKETER, PUBLISHER, ADMIN }
