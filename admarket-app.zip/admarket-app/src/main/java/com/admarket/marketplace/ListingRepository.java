package com.admarket.marketplace;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ListingRepository extends JpaRepository<Listing, UUID> {
  List<Listing> findByWebsiteId(UUID websiteId);
}
