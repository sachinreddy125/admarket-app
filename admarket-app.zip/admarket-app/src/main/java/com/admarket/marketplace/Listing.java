package com.admarket.marketplace;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name="listings")
@Getter
@Setter
@NoArgsConstructor
public class Listing {
  @Id
  private UUID id = UUID.randomUUID();

  @Column(name="website_id", nullable=false)
  private UUID websiteId;

  @Column(nullable=false)
  private String title;

  @Column(name="service_type", nullable=false)
  private String serviceType;

  @Column(name="base_price", nullable=false, precision=19, scale=4)
  private BigDecimal basePrice;

  @Column(nullable=false)
  private String currency = "USD";

  @Column(name="turnaround_days", nullable=false)
  private int turnaroundDays = 7;

  @Column(name="created_at", nullable=false)
  private Instant createdAt = Instant.now();
}
