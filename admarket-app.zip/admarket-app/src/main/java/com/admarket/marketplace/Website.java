package com.admarket.marketplace;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name="websites")
@Getter
@Setter
@NoArgsConstructor
public class Website {
  @Id
  private UUID id = UUID.randomUUID();

  @Column(name="publisher_id", nullable=false)
  private UUID publisherId;

  @Column(nullable=false)
  private String domain;

  private String niche;
  private String language;
  private String geo;

  @Column(name="created_at", nullable=false)
  private Instant createdAt = Instant.now();
}
