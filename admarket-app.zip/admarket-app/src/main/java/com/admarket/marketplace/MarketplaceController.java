package com.admarket.marketplace;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/marketplace")
public class MarketplaceController {
  private final ListingRepository listings;

  public MarketplaceController(ListingRepository listings) {
    this.listings = listings;
  }

  @PreAuthorize("hasAnyRole('MARKETER','PUBLISHER','ADMIN')")
  @GetMapping("/listings")
  public List<Listing> browseListings() {
    return listings.findAll();
  }
}
