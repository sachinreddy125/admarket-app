package com.admarket.marketplace;

import com.admarket.user.User;
import com.admarket.user.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/publisher")
public class PublisherController {
  private final UserRepository users;
  private final WebsiteRepository websites;
  private final ListingRepository listings;

  public PublisherController(UserRepository users, WebsiteRepository websites, ListingRepository listings) {
    this.users = users;
    this.websites = websites;
    this.listings = listings;
  }

  private UUID currentUserId(String email) {
    User u = users.findByEmail(email).orElseThrow();
    return u.getId();
  }

  @PreAuthorize("hasRole('PUBLISHER')")
  @PostMapping("/websites")
  public Website createWebsite(@RequestParam String domain,
                               @RequestParam(required=false) String niche,
                               @RequestParam(required=false) String language,
                               @RequestParam(required=false) String geo,
                               Principal principal) {

    Website w = new Website();
    w.setPublisherId(currentUserId(principal.getName()));
    w.setDomain(domain.toLowerCase());
    w.setNiche(niche);
    w.setLanguage(language);
    w.setGeo(geo);
    return websites.save(w);
  }

  @PreAuthorize("hasRole('PUBLISHER')")
  @GetMapping("/websites")
  public List<Website> myWebsites(Principal principal) {
    return websites.findByPublisherId(currentUserId(principal.getName()));
  }

  @PreAuthorize("hasRole('PUBLISHER')")
  @PostMapping("/listings")
  public Listing createListing(@RequestParam UUID websiteId,
                               @RequestParam String title,
                               @RequestParam String serviceType,
                               @RequestParam BigDecimal basePrice,
                               @RequestParam(defaultValue="USD") String currency,
                               @RequestParam(defaultValue="7") int turnaroundDays,
                               Principal principal) {

    Website w = websites.findById(websiteId).orElseThrow();
    if (!w.getPublisherId().equals(currentUserId(principal.getName()))) {
      throw new IllegalArgumentException("Not your website");
    }

    Listing l = new Listing();
    l.setWebsiteId(websiteId);
    l.setTitle(title);
    l.setServiceType(serviceType);
    l.setBasePrice(basePrice);
    l.setCurrency(currency);
    l.setTurnaroundDays(turnaroundDays);
    return listings.save(l);
  }
}
