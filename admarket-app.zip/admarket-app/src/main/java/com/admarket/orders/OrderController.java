package com.admarket.orders;

import com.admarket.marketplace.Listing;
import com.admarket.marketplace.ListingRepository;
import com.admarket.marketplace.Website;
import com.admarket.marketplace.WebsiteRepository;
import com.admarket.user.User;
import com.admarket.user.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

  private final OrderRepository orders;
  private final OrderService service;
  private final ListingRepository listings;
  private final WebsiteRepository websites;
  private final UserRepository users;

  public OrderController(OrderRepository orders, OrderService service,
                         ListingRepository listings, WebsiteRepository websites, UserRepository users) {
    this.orders = orders;
    this.service = service;
    this.listings = listings;
    this.websites = websites;
    this.users = users;
  }

  private UUID currentUserId(String email) {
    User u = users.findByEmail(email).orElseThrow();
    return u.getId();
  }

  public record CreateOrderRequest(UUID listingId, String requirements) {}

  @PreAuthorize("hasRole('MARKETER')")
  @PostMapping
  public Order create(@RequestBody CreateOrderRequest req, Principal principal) {
    Listing listing = listings.findById(req.listingId()).orElseThrow();
    Website website = websites.findById(listing.getWebsiteId()).orElseThrow();

    return service.createOrder(req.listingId(), req.requirements(), website.getPublisherId(), principal.getName());
  }

  @PreAuthorize("hasRole('MARKETER')")
  @PostMapping("/{id}/fund")
  public Order fund(@PathVariable UUID id, Principal principal) {
    return service.fund(id, principal.getName());
  }

  @PreAuthorize("hasRole('PUBLISHER')")
  @PostMapping("/{id}/accept")
  public Order accept(@PathVariable UUID id, Principal principal) {
    return service.accept(id, principal.getName());
  }

  @PreAuthorize("hasRole('PUBLISHER')")
  @PostMapping("/{id}/deliver")
  public Order deliver(@PathVariable UUID id, Principal principal) {
    return service.deliver(id, principal.getName());
  }

  @PreAuthorize("hasRole('MARKETER')")
  @PostMapping("/{id}/approve")
  public Order approve(@PathVariable UUID id, Principal principal) {
    return service.approveAndRelease(id, principal.getName());
  }

  @PreAuthorize("hasRole('MARKETER')")
  @GetMapping("/my")
  public List<Order> myOrders(Principal principal) {
    return orders.findByMarketerId(currentUserId(principal.getName()));
  }

  @PreAuthorize("hasRole('PUBLISHER')")
  @GetMapping("/inbox")
  public List<Order> publisherInbox(Principal principal) {
    return orders.findByPublisherId(currentUserId(principal.getName()));
  }
}
