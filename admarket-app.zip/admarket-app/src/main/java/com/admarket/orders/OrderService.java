package com.admarket.orders;

import com.admarket.ledger.LedgerService;
import com.admarket.ledger.WalletAccount;
import com.admarket.ledger.WalletAccountRepository;
import com.admarket.marketplace.Listing;
import com.admarket.marketplace.ListingRepository;
import com.admarket.user.User;
import com.admarket.user.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class OrderService {

  private static final UUID PLATFORM_ESCROW_USER_ID =
      UUID.fromString("00000000-0000-0000-0000-000000000001");

  private final OrderRepository orders;
  private final ListingRepository listings;
  private final UserRepository users;
  private final WalletAccountRepository wallets;
  private final LedgerService ledger;

  public OrderService(OrderRepository orders, ListingRepository listings, UserRepository users,
                      WalletAccountRepository wallets, LedgerService ledger) {
    this.orders = orders;
    this.listings = listings;
    this.users = users;
    this.wallets = wallets;
    this.ledger = ledger;
  }

  private UUID userIdByEmail(String email) {
    User u = users.findByEmail(email).orElseThrow();
    return u.getId();
  }

  private UUID walletIdByUser(UUID userId) {
    return wallets.findByUserId(userId).orElseThrow().getId();
  }

  private UUID ensurePlatformEscrowWallet(String currency) {
    return wallets.findByUserId(PLATFORM_ESCROW_USER_ID)
        .orElseGet(() -> wallets.save(WalletAccount.createForUser(PLATFORM_ESCROW_USER_ID, currency)))
        .getId();
  }

  @Transactional
  public Order createOrder(UUID listingId, String requirements, UUID publisherId, String marketerEmail) {
    UUID marketerId = userIdByEmail(marketerEmail);
    Listing listing = listings.findById(listingId).orElseThrow();

    Order o = new Order();
    o.setListingId(listingId);
    o.setMarketerId(marketerId);
    o.setPublisherId(publisherId);
    o.setRequirements(requirements);
    o.setPrice(listing.getBasePrice());
    o.setCurrency(listing.getCurrency());
    o.setStatus(OrderStatus.CREATED);
    return orders.save(o);
  }

  @Transactional
  public Order fund(UUID orderId, String marketerEmail) {
    Order o = orders.findById(orderId).orElseThrow();
    UUID marketerId = userIdByEmail(marketerEmail);
    if (!o.getMarketerId().equals(marketerId)) throw new IllegalArgumentException("Not your order");
    if (o.getStatus() != OrderStatus.CREATED) throw new IllegalStateException("Order not in CREATED");

    UUID marketerWallet = walletIdByUser(marketerId);
    UUID escrowWallet = ensurePlatformEscrowWallet(o.getCurrency());

    ledger.transfer(marketerWallet, escrowWallet, o.getPrice(), o.getCurrency(), "ORDER_ESCROW");
    o.setStatus(OrderStatus.FUNDED);
    return orders.save(o);
  }

  @Transactional
  public Order accept(UUID orderId, String publisherEmail) {
    Order o = orders.findById(orderId).orElseThrow();
    UUID publisherId = userIdByEmail(publisherEmail);
    if (!o.getPublisherId().equals(publisherId)) throw new IllegalArgumentException("Not your order");
    if (o.getStatus() != OrderStatus.FUNDED) throw new IllegalStateException("Order not FUNDED");
    o.setStatus(OrderStatus.ACCEPTED);
    return orders.save(o);
  }

  @Transactional
  public Order deliver(UUID orderId, String publisherEmail) {
    Order o = orders.findById(orderId).orElseThrow();
    UUID publisherId = userIdByEmail(publisherEmail);
    if (!o.getPublisherId().equals(publisherId)) throw new IllegalArgumentException("Not your order");
    if (o.getStatus() != OrderStatus.ACCEPTED) throw new IllegalStateException("Order not ACCEPTED");
    o.setStatus(OrderStatus.DELIVERED);
    return orders.save(o);
  }

  @Transactional
  public Order approveAndRelease(UUID orderId, String marketerEmail) {
    Order o = orders.findById(orderId).orElseThrow();
    UUID marketerId = userIdByEmail(marketerEmail);
    if (!o.getMarketerId().equals(marketerId)) throw new IllegalArgumentException("Not your order");
    if (o.getStatus() != OrderStatus.DELIVERED) throw new IllegalStateException("Order not DELIVERED");

    UUID escrowWallet = ensurePlatformEscrowWallet(o.getCurrency());
    UUID publisherWallet = walletIdByUser(o.getPublisherId());

    ledger.transfer(escrowWallet, publisherWallet, o.getPrice(), o.getCurrency(), "ORDER_RELEASE");
    o.setStatus(OrderStatus.RELEASED);
    return orders.save(o);
  }
}
