package com.admarket.orders;

public enum OrderStatus {
  CREATED, FUNDED, ACCEPTED, DELIVERED, RELEASED, CANCELLED
}
