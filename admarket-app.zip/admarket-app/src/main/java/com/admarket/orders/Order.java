package com.admarket.orders;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name="orders")
@Getter
@Setter
@NoArgsConstructor
public class Order {
  @Id
  private UUID id = UUID.randomUUID();

  @Column(name="listing_id", nullable=false)
  private UUID listingId;

  @Column(name="marketer_id", nullable=false)
  private UUID marketerId;

  @Column(name="publisher_id", nullable=false)
  private UUID publisherId;

  @Column(columnDefinition="text")
  private String requirements;

  @Enumerated(EnumType.STRING)
  @Column(nullable=false)
  private OrderStatus status = OrderStatus.CREATED;

  @Column(nullable=false, precision=19, scale=4)
  private BigDecimal price;

  @Column(nullable=false)
  private String currency;

  @Column(name="created_at", nullable=false)
  private Instant createdAt = Instant.now();
}
