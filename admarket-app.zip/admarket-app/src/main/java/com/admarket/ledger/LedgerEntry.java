package com.admarket.ledger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name="ledger_entries")
@Getter
@Setter
@NoArgsConstructor
public class LedgerEntry {
  @Id
  private UUID id = UUID.randomUUID();

  @Column(name="account_id", nullable=false)
  private UUID accountId;

  @Enumerated(EnumType.STRING)
  @Column(nullable=false)
  private EntryType type;

  @Column(nullable=false, precision=19, scale=4)
  private BigDecimal amount;

  @Column(nullable=false)
  private String currency;

  @Column(name="txn_id", nullable=false)
  private UUID txnId;

  @Column(nullable=false)
  private String reason;

  @Column(name="created_at", nullable=false)
  private Instant createdAt = Instant.now();
}
