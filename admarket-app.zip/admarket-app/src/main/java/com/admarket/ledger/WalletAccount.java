package com.admarket.ledger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name="wallet_accounts")
@Getter
@Setter
@NoArgsConstructor
public class WalletAccount {
  @Id
  private UUID id = UUID.randomUUID();

  @Column(name="user_id", nullable=false, unique=true)
  private UUID userId;

  @Column(nullable=false)
  private String currency = "USD";

  @Column(name="created_at", nullable=false)
  private Instant createdAt = Instant.now();

  public static WalletAccount createForUser(UUID userId, String currency) {
    WalletAccount wa = new WalletAccount();
    wa.setUserId(userId);
    wa.setCurrency(currency);
    return wa;
  }
}
