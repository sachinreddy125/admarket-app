package com.admarket.ledger;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Service
public class LedgerService {
  private final LedgerEntryRepository entries;

  public LedgerService(LedgerEntryRepository entries) {
    this.entries = entries;
  }

  @Transactional
  public UUID transfer(UUID fromAccount, UUID toAccount, BigDecimal amount, String currency, String reason) {
    if (amount == null || amount.signum() <= 0) throw new IllegalArgumentException("amount must be > 0");
    UUID txnId = UUID.randomUUID();

    entries.save(make(fromAccount, EntryType.DEBIT, amount, currency, txnId, reason));
    entries.save(make(toAccount, EntryType.CREDIT, amount, currency, txnId, reason));

    return txnId;
  }

  private LedgerEntry make(UUID accountId, EntryType type, BigDecimal amount, String currency, UUID txnId, String reason) {
    LedgerEntry e = new LedgerEntry();
    e.setAccountId(accountId);
    e.setType(type);
    e.setAmount(amount);
    e.setCurrency(currency);
    e.setTxnId(txnId);
    e.setReason(reason);
    e.setCreatedAt(Instant.now());
    return e;
  }
}
