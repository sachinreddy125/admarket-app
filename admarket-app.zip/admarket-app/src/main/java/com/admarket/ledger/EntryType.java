package com.admarket.ledger;

public enum EntryType { DEBIT, CREDIT }
