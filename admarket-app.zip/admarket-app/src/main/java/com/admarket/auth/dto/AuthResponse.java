package com.admarket.auth.dto;

public record AuthResponse(String token) {}
