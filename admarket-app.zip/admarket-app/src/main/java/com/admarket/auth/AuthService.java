package com.admarket.auth;

import com.admarket.auth.dto.AuthResponse;
import com.admarket.auth.dto.LoginRequest;
import com.admarket.auth.dto.RegisterRequest;
import com.admarket.config.JwtService;
import com.admarket.ledger.WalletAccount;
import com.admarket.ledger.WalletAccountRepository;
import com.admarket.user.Role;
import com.admarket.user.User;
import com.admarket.user.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
  private final UserRepository users;
  private final WalletAccountRepository wallets;
  private final PasswordEncoder encoder;
  private final JwtService jwt;

  public AuthService(UserRepository users, WalletAccountRepository wallets, PasswordEncoder encoder, JwtService jwt) {
    this.users = users;
    this.wallets = wallets;
    this.encoder = encoder;
    this.jwt = jwt;
  }

  public AuthResponse register(RegisterRequest req) {
    String email = req.email().toLowerCase();
    if (users.existsByEmail(email)) {
      throw new IllegalArgumentException("Email already exists");
    }

    Role role = Role.valueOf(req.role().toUpperCase());
    if (role != Role.MARKETER && role != Role.PUBLISHER) {
      throw new IllegalArgumentException("role must be MARKETER or PUBLISHER");
    }

    User u = new User();
    u.setEmail(email);
    u.setPasswordHash(encoder.encode(req.password()));
    u.setRole(role);
    users.save(u);

    WalletAccount wa = WalletAccount.createForUser(u.getId(), "USD");
    wallets.save(wa);

    String token = jwt.issueToken(u.getEmail(), u.getRole().name());
    return new AuthResponse(token);
  }

  public AuthResponse login(LoginRequest req) {
    String email = req.email().toLowerCase();
    User u = users.findByEmail(email)
        .orElseThrow(() -> new IllegalArgumentException("Invalid login"));

    if (!encoder.matches(req.password(), u.getPasswordHash())) {
      throw new IllegalArgumentException("Invalid login");
    }

    String token = jwt.issueToken(u.getEmail(), u.getRole().name());
    return new AuthResponse(token);
  }
}
