CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
  id uuid PRIMARY KEY,
  email varchar(320) NOT NULL UNIQUE,
  password_hash varchar(255) NOT NULL,
  role varchar(32) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Platform/system user (escrow wallet owner).
INSERT INTO users (id, email, password_hash, role)
VALUES ('00000000-0000-0000-0000-000000000001', 'platform@system.local', 'SYSTEM', 'ADMIN')
ON CONFLICT (email) DO NOTHING;

CREATE TABLE wallet_accounts (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  currency varchar(8) NOT NULL DEFAULT 'USD',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE websites (
  id uuid PRIMARY KEY,
  publisher_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  domain varchar(255) NOT NULL,
  niche varchar(120),
  language varchar(32),
  geo varchar(32),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX websites_publisher_domain_uq ON websites(publisher_id, domain);

CREATE TABLE listings (
  id uuid PRIMARY KEY,
  website_id uuid NOT NULL REFERENCES websites(id) ON DELETE CASCADE,
  title varchar(255) NOT NULL,
  service_type varchar(64) NOT NULL,
  base_price numeric(19,4) NOT NULL,
  currency varchar(8) NOT NULL DEFAULT 'USD',
  turnaround_days int NOT NULL DEFAULT 7,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE orders (
  id uuid PRIMARY KEY,
  listing_id uuid NOT NULL REFERENCES listings(id),
  marketer_id uuid NOT NULL REFERENCES users(id),
  publisher_id uuid NOT NULL REFERENCES users(id),
  requirements text,
  status varchar(32) NOT NULL,
  price numeric(19,4) NOT NULL,
  currency varchar(8) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ledger_entries (
  id uuid PRIMARY KEY,
  account_id uuid NOT NULL REFERENCES wallet_accounts(id),
  type varchar(16) NOT NULL,
  amount numeric(19,4) NOT NULL,
  currency varchar(8) NOT NULL,
  txn_id uuid NOT NULL,
  reason varchar(64) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX ledger_entries_account_id_idx ON ledger_entries(account_id);
CREATE INDEX ledger_entries_txn_id_idx ON ledger_entries(txn_id);
